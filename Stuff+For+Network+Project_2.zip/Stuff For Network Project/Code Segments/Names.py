#THESE ARE THE NAMES FOR HANDLING THE REQUESTS FROM THE CLIENT 
#WE IMPORT THESE NAMES INTO SERVER PART

image_as_png = "GET /.png HTTP/1.1\r" #PNG IMAGE
image_as_jpg = "GET /.jpg HTTP/1.1\r" #JPG IMAGE
client_server_as_png = "GET /client_server.png HTTP/1.1\r" #client_server_as_png IMAGE
lastImage_as_jpg = "GET /lastImage.jpg HTTP/1.1\r" #lastImage IMAGE....AND SO ON AND SO FORTH
extension_with_file_css = "GET /Style.css HTTP/1.1\r" 
extension_with_css = "GET /.css HTTP/1.1\r"
extension_with_space_slash_space = "GET / HTTP/1.1\r"
extension_with_slash_index_html = "GET /index.html HTTP/1.1\r"
extension_with_slash_main_en_html = "GET /main_en.html HTTP/1.1\r"
extension_with_slash_en_html = "GET /en HTTP/1.1\r"
extension_with_html = "GET /.html HTTP/1.1\r"
icon = "GET /images/haloween.jpg HTTP/1.1\r"
extension_with_ar_html = "GET /ar HTTP/1.1\r"
extension_with_go = "GET /go HTTP/1.1\r"
extension_with_so = "GET /so HTTP/1.1\r"
extension_with_bzu = "GET /bzu HTTP/1.1\r"
copy_file = "GET /friday.html HTTP/1.1\r"