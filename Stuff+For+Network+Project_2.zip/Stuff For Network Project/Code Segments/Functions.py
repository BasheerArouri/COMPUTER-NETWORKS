
#FUNCTION FOR SHOWING THE png EXTENSION
def show_the_png_extension(connectionSocket):

    connectionSocket.send("HTTP/1.1 200 OK \r\n".encode())
    print("THX, YOUR REQUEST IS AN IMAGE WITH EXTENSION png.")
    connectionSocket.send("Content-Type: image/png; charset=utf-8 \r\n".encode())
    with open("client_server.png", "rb") as file:
        data = file.read()
    length = ("Content - Length:" + str(len(data)) + "\r\n")
    connectionSocket.send(length.encode())
    connectionSocket.send("\r\n".encode())
    connectionSocket.send(data)

#FUNCTION FOR SHOWING THE jpg EXTENSION
def show_the_jpg_extenstion(connectionSocket):

    connectionSocket.send("HTTP/1.1 200 OK \r\n".encode())
    print("THX, YOUR REQUEST IS AN IMAGE WITH EXTENSION jpg.")
    connectionSocket.send("Content-Type: image/jpg; charset=utf-8 \r\n".encode())
    with open("lastImage.jpg", "rb") as file:
        data = file.read()
    length = ("Content - Length:" + str(len(data)) + "\r\n")
    connectionSocket.send(length.encode())
    connectionSocket.send("\r\n".encode())
    connectionSocket.send(data)

#FUNCTION FOR SHOWING THE css EXTENSION
def show_the_css_extenstion(connectionSocket):

    connectionSocket.send("HTTP/1.1 200 OK \r\n".encode())
    print("THX, YOUR REQUEST IS A TEXT WITH EXTENSION css.")
    connectionSocket.send("Content-Type: text/css; charset=utf-8 \r\n".encode())
    with open("Style.css", "rb") as file:
        data = file.read()
    length = ("Content - Length:" + str(len(data)) + "\r\n")
    connectionSocket.send(length.encode())
    connectionSocket.send("\r\n".encode())
    connectionSocket.send(data)

#FUNCTION FOR SHOWING THE html EXTENSION
def show_the_different_html_extenstion(connectionSocket):

    connectionSocket.send("HTTP/1.1 200 OK \r\n".encode())
    print("THX, YOUR REQUEST IS THE WHOLE WEBPAGE")
    connectionSocket.send("Content-Type: text/html; charset=utf-8 \r\n".encode())
    with open("main_en.html", "rb") as file:
        data = file.read()
    length = ("Content - Length:" + str(len(data)) + "\r\n")
    connectionSocket.send(length.encode())
    connectionSocket.send("\r\n".encode())
    connectionSocket.send(data)

#FUNCTION FOR SHOWING THE friday.hmtl EXTENSION FILE
def show_the_html_extenstion(connectionSocket):

    connectionSocket.send("HTTP/1.1 200 OK \r\n".encode())
    print("THX, YOUR REQUEST IS THE HTML EXTENSION")
    connectionSocket.send("Content-Type: text/html; charset=utf-8 \r\n".encode())
    with open("friday.html", "rb") as file:
        data = file.read()
    length = ("Content - Length:" + str(len(data)) + "\r\n")
    connectionSocket.send(length.encode())
    connectionSocket.send("\r\n".encode())
    connectionSocket.send(data)

#FUNCTION FOR SHOWING THE bird IMAGE
def show_the_bird_image(connectionSocket):

    connectionSocket.send("HTTP/1.1 200 OK \r\n".encode())
    print("THX, YOUR REQUEST IS AN IMAGE WITH EXTENSION png.")
    connectionSocket.send("Content-Type: image/png; charset=utf-8 \r\n".encode())
    with open("bird.jpg", "rb") as file:
        data = file.read()
    length = ("Content - Length:" + str(len(data)) + "\r\n")
    connectionSocket.send(length.encode())
    connectionSocket.send("\r\n".encode())
    connectionSocket.send(data)

#FUNCTION FOR SHOWING THE images/haloween
def show_icon(connectionSocket):

    connectionSocket.send("HTTP/1.1 200 OK \r\n".encode())
    print("THX, YOUR REQUEST IS AN IMAGE WITH EXTENSION jpg.")
    connectionSocket.send("Content-Type: image/jpg; charset=utf-8 \r\n".encode())
    with open("images/haloween.jpg", "rb") as file:
        data = file.read()
    length = ("Content - Length:" + str(len(data)) + "\r\n")
    connectionSocket.send(length.encode())
    connectionSocket.send("\r\n".encode())
    connectionSocket.send(data)

#FUNCTION FOR SHOWING THE ARBIC FILE
def show_the_html_extenstion_arabic_version(connectionSocket):

    connectionSocket.send("HTTP/1.1 200 OK \r\n".encode())
    print("THX, YOUR REQUEST IS HTML FILE EXTENSION ar.")
    connectionSocket.send("Content-Type: text/html; charset=utf-8 \r\n".encode())
    with open("main_ar.html", "rb") as file:
        data = file.read()
    length = ("Content - Length:" + str(len(data)) + "\r\n")
    connectionSocket.send(length.encode())
    connectionSocket.send("\r\n".encode())
    connectionSocket.send(data)

#FUNCTION FOR SHOWING THE go EXTENSION
def show_the_go_extenstion(connectionSocket):

    connectionSocket.send("HTTP/1.1 307 Temporary Redirect \r\n".encode())
    print("THX, YOUR REQUEST IS GOOGLE WEBSITE.")
    connectionSocket.send("Content-Type: text/html; charset=utf-8 \r\n".encode())
    connectionSocket.send("Location : https://www.google.com/".encode())
    connectionSocket.send("\r\n".encode())

#FUNCTION FOR SHOWING THE so EXTENSION
def show_the_so_extenstion(connectionSocket):

    connectionSocket.send("HTTP/1.1 307 Temporary Redirect \r\n".encode())
    print("THX, YOUR REQUEST IS STACKOVERFLOW WEBSITE.")
    connectionSocket.send("Content-Type: text/html; charset=utf-8 \r\n".encode())
    connectionSocket.send("Location : https://stackoverflow.com/".encode())
    connectionSocket.send("\r\n".encode())

#FUNCTION FOR SHOWING THE bzu EXTENSION
def show_the_bzu_extenstion(connectionSocket):

    connectionSocket.send("HTTP/1.1 307 Temporary Redirect \r\n".encode())
    print("THX, YOUR REQUEST IS RITAJ WEBSITE.")
    connectionSocket.send("Content-Type: text/html; charset=utf-8 \r\n".encode())
    connectionSocket.send("Location : https://www.birzeit.edu/ar/".encode())
    connectionSocket.send("\r\n".encode())

#FUNCTION FOR SHOWING THE other EXTENSIONS
def show_other_extenstion(connectionSocket, ip, port):

    connectionSocket.send("HTTP/1.1 404 Not Found \r\n".encode())
    connectionSocket.send("Content-Type: text/html; charset=utf-8 \r\n".encode())
    data = get_html_file(ip, port)
    length = ("Content - Length:" + str(len(data)) + "\r\n")
    connectionSocket.send(length.encode())
    connectionSocket.send("\r\n".encode())
    connectionSocket.send(data)

def get_html_file(ip, port):

    s = '<!DOCTYPE html><html lang="en"><head><title>Error</title></head><body><h1 style="color: red; text-align: center; ">The file is not found</h1><div class="names" style="font-weight: bold; text-align: center; "><h1>Basheer Arouri&nbsp;&nbsp;&nbsp;&nbsp;1201141</h1><h1>Momen Salem&nbsp;&nbsp;&nbsp;&nbsp;1200034</h1><h1>Mohammad Khader&nbsp;&nbsp;&nbsp;&nbsp;1201071</h1><h1>The value of IP address  = '  + str(ip) + '</h1><h1>The value of PORT number =  ' + str(port) + '</h1></div></body></html>'

    return s.encode()

#FUNCTION FOR SHOWING THE other EXTENSIONS
def show_the_copy_file(connectionSocket):

    connectionSocket.send("HTTP/1.1 200 OK \r\n".encode())
    print("THX, YOUR REQUEST IS HTML FILE.")
    connectionSocket.send("Content-Type: text/html; charset=utf-8 \r\n".encode())
    with open("friday.html", "rb") as file:
        data = file.read()
    length = ("Content - Length:" + str(len(data)) + "\r\n")
    connectionSocket.send(length.encode())
    connectionSocket.send("\r\n".encode())
    connectionSocket.send(data)


