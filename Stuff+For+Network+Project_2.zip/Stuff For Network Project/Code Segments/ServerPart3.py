from socket import * #IMPORT ALL THE SOCKET FUNCTIONS AND NAMES OF IT
from Names import * #IMPORT ALL THE NAMES (LOCAL MODULE)
import Functions    #IMPORT FUNCTIONS MODULE
serverPort = 7788  
serverSocket = socket(AF_INET, SOCK_STREAM)  #CREATE A SOCKET
serverSocket.bind(("", serverPort))  #BINDING OUR SERVER NUMBER (7788) WITH THE SYSTEM SERVER
serverSocket.listen(10)              #LISTENING FOR REQUESTS FROM CLIENTS
print("The server is ready to receive")

while True:  
    try:
        connectionSocket, addr = serverSocket.accept()  #GET SOME INFO ABOUT THE REQUEST
        sentence = connectionSocket.recv(1024).decode()  #GET THE REQUEST FROM THE CLIENT
        print(sentence)   #PRINT THE REQUEST 
        ip = addr[0]      #IP ADDRESS FROM THE CLIENT (127.0.0.1)
        port = addr[1]    #PORT NUMBER FROM THE CLIENT

        first_line = sentence.split("\n")[0] #GETTING THE REQUEST

        #FROM HERE THE CONDITIONS...

        if first_line == image_as_png: #IF THE REQUEST IS IMAGE WITH EXTENSION /.png
            Functions.show_the_png_extension(connectionSocket) #RUN THIS FUNCTION

        elif first_line == image_as_jpg: #IF THE REQUEST IS IMAGE WITH EXTENSION /.jpg
            Functions.show_the_jpg_extenstion(connectionSocket)

        elif first_line == extension_with_css: #IF THE REQUEST IS FILE WITH EXTENSION /.css
            Functions.show_the_css_extenstion(connectionSocket) #RUN THIS FUNCTION

        elif first_line == extension_with_space_slash_space or first_line == extension_with_slash_index_html: 
            #IF THE REQUEST IS FILE WITH EXTENSION / or THE REQUEST IS FILE WITH EXTENSION /index
            Functions.show_the_different_html_extenstion(connectionSocket) #RUN THIS FUNCTION

        elif first_line == extension_with_slash_en_html or first_line == extension_with_slash_main_en_html:
            #IF THE REQUEST IS FILE WITH EXTENSION /en or THE REQUEST IS FILE WITH EXTENSION /main_en
            Functions.show_the_different_html_extenstion(connectionSocket) #RUN THIS FUNCTION

        elif first_line == extension_with_html: #IF THE REQUEST IS FILE WITH EXTENSION /.html
            Functions.show_the_html_extenstion(connectionSocket) #RUN THIS FUNCTION

        #FOR HANDLING THE PICTURES AND THE CSS FILE
        elif first_line == client_server_as_png: #IF THE REQUEST IS IMAGE WITH EXTENSION /.png
            Functions.show_the_png_extension(connectionSocket) #RUN THIS FUNCTION

        elif first_line == lastImage_as_jpg: #IF THE REQUEST IS lastImage_as_jpg 
            Functions.show_the_jpg_extenstion(connectionSocket) #RUN THIS FUNCTION

        elif first_line == extension_with_file_css: #IF THE REQUEST IS Style.css (OUR SEPRATE CSS FILE) 
            Functions.show_the_css_extenstion(connectionSocket) #RUN THIS FUNCTION

        elif first_line == icon:  #IF THE REQUEST IS images/haloween.jpg
            Functions.show_icon(connectionSocket) #RUN THIS FUNCTION

        elif first_line == extension_with_ar_html: #IF THE REQUEST IS FILE WITH EXTENSION /ar
            Functions.show_the_html_extenstion_arabic_version(connectionSocket) #RUN THIS FUNCTION
        
        elif first_line == extension_with_go:  #IF THE REQUEST IS /go(GOOGLE)
            Functions.show_the_go_extenstion(connectionSocket) #RUN THIS FUNCTION
        
        elif first_line == extension_with_so: #IF THE REQUEST IS /so(STACKOVERFLOW)
            Functions.show_the_so_extenstion(connectionSocket) #RUN THIS FUNCTION

        elif first_line == extension_with_bzu: #IF THE REQUEST IS /bzu(BIRZEIT)
            Functions.show_the_bzu_extenstion(connectionSocket) #RUN THIS FUNCTION

        elif first_line == copy_file: #IF THE REQUEST IS /bzu(BIRZEIT)
            Functions.show_the_copy_file(connectionSocket) #RUN THIS FUNCTION

        else:  #IF THE REQUEST IS NOT FROM ALL THE ABOVE
            Functions.show_other_extenstion(connectionSocket, ip, port) #RUN THIS FUNCTION

            
        connectionSocket.close() #CLOSE THE CONNCECTION OF THIS REQUEST

    except OSError:
        print("IO error")
